import mongoose, { Document, Schema } from "mongoose";

interface IMarketPrice extends Document {
  State: string;
  District: string;
  Market: string;
  Commodity: string;
  Variety: string;
  Grade: string;
  ArrivalDate: Date;
  Min_x0020_Price: number;
  Max_x0020_Price: number;
  Modal_x0020_Price: number;
}

const MarketPriceSchema = new Schema<IMarketPrice>(
  {
    State: { type: String, required: true },
    District: { type: String, required: true },
    Market: { type: String, required: true },
    Commodity: { type: String, required: true },
    Variety: { type: String, required: true },
    Grade: { type: String, required: true },
    ArrivalDate: { type: Date, required: true },
    Min_x0020_Price: { type: Number, required: true },
    Max_x0020_Price: { type: Number, required: true },
    Modal_x0020_Price: { type: Number, required: true },
  },
  {
    timestamps: true, // Adds createdAt and updatedAt fields
  }
);

// Creating an index for optimized queries (e.g., searching by state, district, and market)
MarketPriceSchema.index({ state: 1, district: 1, market: 1, commodity: 1 });

const MarketPriceModel = mongoose.model<IMarketPrice>(
  "MarketPrice",
  MarketPriceSchema
);

export default MarketPriceModel;
export { IMarketPrice };

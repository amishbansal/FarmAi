import axios from "axios";

export function toTitleCase(str: string) {
  return str
    .toLowerCase()
    .split(" ")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}

export const normalizeChunk = (chunk: any) => {
  if (typeof chunk === "string") {
    return chunk;
  } else {
    return "";
  }
};


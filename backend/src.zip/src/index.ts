import { Hono } from "hono";
import { cors } from "hono/cors";

//controllers
import streamChatController from "./controllers/stream-chat";
import aiChatController from "./controllers/chat";
import testROuter from "./controllers/test";
import mongodb from "./config/db/mongodb";
import mandiDataRoute from "./controllers/market-prices";
import { setupDatasetAndExamples } from "./config/evaluation/dataset/example-dataset";

const app = new Hono();

//db connection
(async () => {
  await mongodb.connect();
})();

// setupDatasetAndExamples()
//   .then(() => console.log("Dataset creation completed."))

app.use("/*", cors());

app.get("/health", (c) => {
  return c.text("Everything Working Awesome!");
});

app
  .route("/api", mandiDataRoute)
  .route("/ai", streamChatController)
  .route("/ai", aiChatController)
  .route("/t", testROuter);
// app.route("/ai", aiChatController);

export default app;

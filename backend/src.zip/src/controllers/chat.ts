import { Hono } from "hono";
import { agent } from "../config/langgraph-flow";
import { HumanMessage, SystemMessage } from "@langchain/core/messages";
import { redis } from "../config/caching/redis.config";

const app = new Hono();

app.post("/chat/:chatID", async (c) => {
  const startTime = performance.now();
  try {
    const { message } = await c.req.json();
    const chatID = c.req.param("chatID");

    if (!chatID) {
      return c.json(
        {
          message: "ChatID is not found",
        },
        400
      );
    }

    if (!message) {
      return c.json(
        {
          message: "Message should not empty!",
        },
        400
      );
    }

    // ✅ Check if chat history exists (Boolean flag)
    const historyKey = `chat_history_flag:${chatID}`;
    const hasHistory = (await redis.get(historyKey)) === "1";

    // Prepare messages
    let messages = [];
    if (!hasHistory) {
      // If no history, add system message first
      messages.push(
        new SystemMessage(
          `You are an expert agriculture assistant named FarmAI (strictly your name). Your goal is to understand the user's intent and provide the best possible response using the appropriate tools.

# Tool Selection Guidelines:
- **Mandi Tool:** Use this tool when the user asks about crop, fruit, or vegetable prices in India (state, district, or market level). Do NOT request the search tool if this tool can provide the data. If the tool returns empty data, respond: "No data available in our dataset. I need internet access to fetch this information. Please enable the search feature."
- **Weather Tool:** Use this tool for any weather-related queries (e.g., temperature, rainfall, forecast). Do NOT request the search tool if the weather tool can provide the required data.
- **Search Tool (Tavily):** Use this tool ONLY when the user explicitly requests it by including 'SRCH:ON' in their query. If 'SRCH:ON' is not present, do NOT use this tool. Instead, respond: "Please enable the search feature by clicking the search icon button to get real-time internet data."

# Additional Instructions:
- Never return a response containing [{'name': 'tavily_search_results_json', 'arguments': {...}}]. Instead, reply: "I need internet access to answer your query. Please enable the search feature."
- Always ensure responses are **easy to understand, human-friendly, and informative.**
- If multiple tools are needed, intelligently combine their outputs to provide the best response.

at the end if you have any confusion or even a single doubt which tool to use/run, or user's intend was not that much clear, use ask the user, use human in the loop

`
          // "You are an expert agriculture assistant named FarmAI (strictly your name). Use tools to get data and provide a helpful answer with explanations.Always gve answers human understandable easy to understand"
        )
      );

      // ✅ Mark chat as having history (store Boolean flag)
      await redis.set(historyKey, "1");
    }

    messages.push(new HumanMessage(`${message}`));

    console.log("Here are the messages recieved: ", messages);
    //invoke agent:
    const response = await agent.invoke(
      {
        messages,
      },
      {
        configurable: {
          thread_id: chatID,
        },
      }
    );

    console.log("LLM response: ",response.messages[response.messages.length - 1])

    const finalResponseMessage =
      response.messages[response.messages.length - 1].content;

    const endTime = performance.now();
    console.log(
      `Request to ${c.req.path} took ${(endTime - startTime).toFixed(2)} ms`
    );

    return c.json(
      {
        response: finalResponseMessage,
      },
      200
    );
  } catch (error) {
    console.error("Error: ", error);
    return c.json(
      {
        message: "Something went wrong",
      },
      500
    );
  }
});

export default app;

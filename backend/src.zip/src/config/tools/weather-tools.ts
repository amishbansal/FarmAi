import { TavilySearchResults } from "@langchain/community/tools/tavily_search";
import { StructuredToolParams, tool } from "@langchain/core/tools";
import axios from "axios";
import { z } from "zod";
import { redis } from "../caching/redis.config";
import { toTitleCase } from "../../utils/helpers";

export const searchTool = new TavilySearchResults({
  maxResults: 3,
  apiKey: process.env.TAVILY_API_KEY!,
});

const weatherToolIPSchema = z.object({
  city: z.string().describe("City name for which you want to get the weather"),
});

const weatherToolSchema: StructuredToolParams = {
  name: "get_current_weather",
  description:
    "Get the real-time current weather information and weather forecast information for any city in the world",
  schema: weatherToolIPSchema,
};

export const weatherTool = tool(async (input): Promise<string> => {
  try {
    console.log("Weather tool invoked");
    const startTime = performance.now();

    //@ts-ignore

    const weatherData = await redis.get(`${toTitleCase(input.city)}`);
    if (weatherData) {
      console.log("From Caching: ", weatherData);
      const endTime = performance.now();
      console.log(
        `weather exec time took ${(endTime - startTime).toFixed(2)} ms`
      );
      return weatherData;
    }
    const res = await axios.get(
      // `https://api.openweathermap.org/data/2.5/weather?lat=${input.latitude}&lon=${input.latitude}&appid=53f03aed53507ad5ff0aa427d6e56852`
      `https://api.openweathermap.org/data/2.5/forecast?q=${toTitleCase(
        //@ts-ignore
        input.city
      )}&units=metric&appid=53f03aed53507ad5ff0aa427d6e56852`
    );

    const endTime = performance.now();
    console.log(
      `weather exec time took ${(endTime - startTime).toFixed(2)} ms`
    );

    const data = JSON.stringify(res.data);
    //@ts-ignore

    await redis.set(`${toTitleCase(input.city)}`, data, "EX", 86400);

    return data;
  } catch (error) {
    return `Something went wrong while getting weather data for your location`;
  }
}, weatherToolSchema);

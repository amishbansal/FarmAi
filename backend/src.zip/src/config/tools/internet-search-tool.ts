import { StructuredToolParams, tool } from "@langchain/core/tools"
import { z } from "zod";
import { searchTool } from "./weather-tools";

const internetSearchToolScheama = z.object({
  query: z.string().optional().describe("Query to search on internet for agricultural purpose only"),
});

const internetSearchToolSchema: StructuredToolParams = {
  name: "internet_search_tool",
  description:
    "Fetch information from the internet for agricultural purpose only. This tool provides information about user queries realted to agricultural purpose only.",
  schema: internetSearchToolScheama // No input needed
};

export const internetSearchTool = tool(async (input:any): Promise<string> => {

    try {
        const res = await searchTool.invoke(input.query);
        console.log("Internet Search Tool Invoked:: ", res)

        return res;
    } catch (error) {
        console.error("Error while internet fetching ",error);
        return "Something went wrong while fetching the information from internet.";
    }
}, internetSearchToolSchema)
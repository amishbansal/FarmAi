import { StructuredToolParams, tool } from "@langchain/core/tools";
import { z } from "zod";
import { searchTool } from "./weather-tools";

const globalMarketInfoToolSchema = z.object({
  comodity: z.string().describe("Comodity name"),
  country: z.string().optional().describe("Country Name, this is optional can ignore if not provded"),
});

const globalInfoStructuredToolSchema: StructuredToolParams = {
  name: "get_global_market_comodity_info",
  description:
    "Get the global or international market price information for a specific comodity. This tool provides information about the global market price of a specific comodity.",
  schema: globalMarketInfoToolSchema,
};

export const globalComodityInfoTool = tool(async (input: any) => {
  try {
    
    const res = await searchTool.invoke(
        "site:numbeo.com global market export price for " + input.comodity + input.country ? " in " + input.country : "",
    );
    console.log("comodity Info Tool Invoked:: ", res);
    return res;
  } catch (error) {
    console.error("Error while getting comodity international info: ", error);
    return "Something went wrong while fetching the comodity information from international market.";
  }
}, globalInfoStructuredToolSchema);

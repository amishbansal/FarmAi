import { StructuredToolParams, tool } from "@langchain/core/tools";
import { z } from "zod";
import { searchTool } from "./weather-tools";

const pesticidesInfoToolSchema = z.object({
  crop: z.string().describe("Crop name"),
  pest: z.string().optional().describe("Pest name"),
});

const pesticidesInfoStructuredToolSchema: StructuredToolParams = {
  name: "get_pesticide_info",
  description:
    "Get the pesticides information for a specific crop and pest. This tool provides information about the pesticides that can be used for a specific crop and pest.",
  schema: pesticidesInfoToolSchema,
};

export const pestcidesInfoTool = tool(async (input: any) => {
  try {
    
    const res = await searchTool.invoke(
      "pesticides for " + input.crop + " " + input?.pest ? input.pest : ""
    );
    console.log("Pesticides Info Tool Invoked:: ", res);
    return res;
  } catch (error) {
    console.error("Error while getting pesticides info: ", error);
    return "Something went wrong while fetching the pesticides information.";
  }
}, pesticidesInfoStructuredToolSchema);

import { StructuredToolParams, tool } from "@langchain/core/tools";
import { z } from "zod";
import { searchTool } from "./weather-tools";

const fertilizerInfoToolSchema = z.object({
  crop: z.string().optional().describe("Crop name"),
  region: z.string().optional().describe("Region name"),
  soilType: z.string().optional().describe("Soil type"),
});

const fertilizerInfoStructuredToolSchema: StructuredToolParams = {
  name: "get_fertilizer_info",
  description:
    "Get the fertilizer information for a specific crop, soil type and region. This tool provides information about the fertilizers that can be used for a specific crop, soil type and region.",
  schema: fertilizerInfoToolSchema,
};

export const fertilizerInfoTool = tool(async (input: any) => {
  try {
    const res = await searchTool.invoke(
      "Give me the fertilizer info for crop: " + input.crop + " " + input?.soilType
        ? "for soil type:"+input.soilType
        : "" + " " 
    );
    console.log("Fertilizer Info Tool Invoked:: ", res);
    return res;
  } catch (error) {
    console.error("Error while getting Fertilizer info: ", error);
    return "Something went wrong while fetching the Fertilizer information.";
  }
}, fertilizerInfoStructuredToolSchema);

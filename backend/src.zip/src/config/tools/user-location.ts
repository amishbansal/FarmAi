import { StructuredToolParams, tool } from "@langchain/core/tools";
import { z } from "zod";
import { searchTool } from "./weather-tools";
import axios from "axios";

const userLocationToolScheama = z.object({
  ipAddress: z.string().optional().describe("IP address of the user"),
});

const governmentSchemes: StructuredToolParams = {
  name: "user_location",
  description: "Gives users location based on their IP address",
  schema: userLocationToolScheama, // No input needed
  // No input needed
};

export const userLocationTool = tool(async (input: any) => {
  const apiKey = process.env.IPGEOLOCATION_API_KEY;

  try {
    const { data } = await axios.get(`https://api.ipgeolocation.io/ipgeo`, {
      params: {
        apiKey,
        ipAddress: input.ipAddress,
      },
    });

    return {
      ipAddress: input.ipAddress,
      location: {
        city: data.city,
        state_prov: data.state_prov,
        country: data.country_name,
        latitude: data.latitude,
        longitude: data.longitude,
      },
    };
  } catch (err) {
    console.error("Geolocation error:", err);
    return { error: "Failed to fetch location" };
  }
}, governmentSchemes);

import { StructuredToolParams, tool } from "@langchain/core/tools";
import { z } from "zod";
import { redis } from "../caching/redis.config";
import MarketPriceModel from "../../models/marketPrice.model";
import { toTitleCase } from "../../utils/helpers";


const mandiToolSchema = z.object({
  state: z
    .string()
    .optional()
    .describe("The state for which mandi data is required, eg: Andhra Pradesh"),
  district: z
    .string()
    .optional()
    .describe("The district for which mandi data is required"),
  market: z.string().optional().describe("The market name for mandi data"),
  commodity: z
    .string()
    .optional()
    .describe("The commodity name to fetch market prices, eg: Tomato"),
  variety: z.string().optional().describe("The variety of the commodity"),
  grade: z.string().optional().describe("The grade of the commodity"),
  limit: z.number().optional().describe("Number of records to fetch"),
  offset: z.number().optional().describe("Offset for pagination"),
});

const mandiToolParams: StructuredToolParams = {
  name: "get_mandi_data",
  description:
    "Fetch real-time mandi (market) prices (in quintel) from MongoDB for commodities based on state, district, market, etc. & all detailes must be filled in english language, It accepts singular forms of comodity, example:  'Tomato' instead of 'Tomatoes'.",
  schema: mandiToolSchema,
};

export const mandiTool = tool(async (input: any): Promise<string> => {
  try {
    console.log("Mandi tool invoked with:", input);
    const startTime = performance.now();

    const query: Record<string, any> = {};

    if (input.state) query.State = toTitleCase(input.state);
    if (input.district) query.District = toTitleCase(input.district);
    if (input.market) query.Market = toTitleCase(input.market);
    if (input.commodity) query.Commodity = toTitleCase(input.commodity);
    if (input.variety) query.Variety = toTitleCase(input.variety);
    if (input.grade) query.Grade = toTitleCase(input.grade);

    const limit = input.limit ?? 10;
    const offset = input.offset ?? 0;

    const cacheKey = `mandi:${JSON.stringify(query)}:${limit}:${offset}`;
    const cachedData = await redis.get(cacheKey);

    if (cachedData) {
      console.log("Returning cached mandi data");
      return cachedData;
    }

    console.log("Querying MongoDB for mandi data...: ", query);

    const mandiData = await MarketPriceModel.find(query)
      .limit(limit)
      .skip(offset)
      .lean(); // `.lean()` improves performance by returning plain JS objects

    const endTime = performance.now();
    console.log(
      `Database exec time took ${(endTime - startTime).toFixed(2)} ms`
    );

    console.log("here is the mandi data: ", mandiData);

    if (!mandiData.length) {
      return "No mandi data found in database";
    }

    const result = JSON.stringify(mandiData, null, 2);

    try {
      // Cache results for 1 hour (3600 seconds)
      await redis.set(cacheKey, result, "EX", 3600);
    } catch (error) {
      console.error("Error caching mandi data:", error);
    }

    return result;
  } catch (error) {
    console.error("Error fetching mandi data from MongoDB:", error);
    return "Failed to fetch mandi data. Please try again later.";
  }
}, mandiToolParams);

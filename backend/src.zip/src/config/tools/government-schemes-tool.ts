import { StructuredToolParams, tool } from "@langchain/core/tools"
import { z } from "zod";
import { searchTool } from "./weather-tools";

const governmentSchemesToolScheama = z.object({
  query: z.string().optional().describe("Query to search for government schemes for farmers"),
});

const governmentSchemes: StructuredToolParams = {
  name: "get_government_schemes",
  description:
    "Fetch government schemes for Indian farmers. This tool provides information about various government schemes available for farmers in India.",
  schema: governmentSchemesToolScheama // No input needed
  // No input needed
};

export const governmentSchemesTool = tool(async (input:any): Promise<string> => {

    try {
        const res = await searchTool.invoke(input.query);
        console.log("Government schemes tool invoked:: ", res)

        return res;
    } catch (error) {
        console.error("Error while getting government schemes tools: ",error);
        return "Something went wrong while fetching the government schemes.";
    }
}, governmentSchemes)
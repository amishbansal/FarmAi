import { ChatMistralAI } from "@langchain/mistralai";
import { MessagesAnnotation } from "@langchain/langgraph";
import { tools } from "./tools/tools";
import { ChatGoogleGenerativeAI } from "@langchain/google-genai";
import { HumanMessage, SystemMessage } from "@langchain/core/messages";
import { Client } from "langsmith";
import { ChatGroq } from "@langchain/groq";
import { ChatOpenAI } from "@langchain/openai";

export const llm = new ChatMistralAI({
  model: "mistral-large-latest",
  maxRetries: 3,
  apiKey: process.env.MISTRAL_API_KEY!,
}).bindTools(tools);

// export const llm = new ChatGroq({
//   model: "DeepSeek-R1-Distill-Llama-70B",
//   temperature: 0.6,
//   // maxTokens: undefined,
//   maxRetries: 2,
//   apiKey: process.env.GROQ_API_KEY!,
//   // other params...
// }).bindTools(tools);

export const visionLLM = new ChatGoogleGenerativeAI({
  apiKey: process.env.GEMINI_API_KEY,
  model: "gemini-2.0-flash",
  temperature: 0.6,
}).bindTools(tools);

//-------------------------------------
export const langsmithClient = new Client();
//-------------------------------------

export async function callModel(state: typeof MessagesAnnotation.State) {
  const lastMessage = state.messages[state.messages.length - 1];

  console.log("📨 Incoming message:", lastMessage);

  // ✅ Extract images properly
  const images: any[] = Array.isArray(lastMessage.additional_kwargs?.images)
    ? lastMessage.additional_kwargs.images
    : [];

  if (images?.length > 0) {
    console.log("📷 Image detected! Using Gemini Vision...");

    const message = new HumanMessage({
      content: [
        {
          type: "text",
          text: lastMessage.content,
        },
        {
          type: "image_url",
          image_url: {
            url: images[0],
          },
        },
      ],
    });

    const response = await visionLLM.invoke([
      new SystemMessage(
        "You are an expert agriculture assistant named FarmAI (strictly your name). Your goal is to understand the user's intent and provide the best possible response, You are expert in plant disease diagnosis, if user ask you about your name the reply with your name 'FarmAI' otherwise just straightly answer user's query"
      ),
      message,
    ]);

    return { messages: [response] };
  }

  console.log("📝 No image detected. Using Mistral for text processing...");
  const response = await visionLLM.invoke(state.messages);
  console.log("LLM response: ", response);

  return { messages: [response] };
}
